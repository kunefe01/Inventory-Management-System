import java.util.List;

interface StockManager<T extends Product> {
    void addProduct(T product);

    void listProducts();

    void updateStock(T product, int quantity);

    void removeProduct(T product);

    List<T> findProductByName(String name);

    boolean checkStockAvailability(T product, int quantity);

    void increaseStock(T product, int quantity);

    void decreaseStock(T product, int quantity);
}
