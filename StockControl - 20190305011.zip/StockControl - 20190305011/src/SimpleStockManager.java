import java.util.ArrayList;
import java.util.List;

class SimpleStockManager<T extends Product> implements StockManager<T> {
    private List<T> products = new ArrayList<>();

    @Override
    public void addProduct(T product) {
        products.add(product);
        System.out.println("Ürün eklendi: " + product.getName());
    }

    @Override
    public void listProducts() {
        System.out.println("Ürünler:");
        for (T product : products) {
            System.out.println(product);
        }
    }

    @Override
    public void updateStock(T product, int quantity) {
        product.updateStock(quantity);
        System.out.println("Stok güncellendi: " + product.getName() + ", Yeni stok: " + product.getStock());
    }

    @Override
    public void removeProduct(T product) {
        products.remove(product);
        System.out.println("Ürün silindi: " + product.getName());
    }

    @Override
    public List<T> findProductByName(String name) {
        List<T> foundProducts = new ArrayList<>();
        for (T product : products) {
            if (product.getName().equalsIgnoreCase(name)) {
                foundProducts.add(product);
            }
        }
        return foundProducts;
    }

    @Override
    public boolean checkStockAvailability(T product, int quantity) {
        return product.getStock() >= quantity;
    }

    @Override
    public void increaseStock(T product, int quantity) {
        product.updateStock(quantity);
        System.out.println("Stok eklendi: " + product.getName() + ", Yeni stok: " + product.getStock());
    }

    @Override
    public void decreaseStock(T product, int quantity) {
        product.decreaseStock(quantity);
    }
}
