import java.util.*;

// Generic Interface

// Generic Class

// Product sınıfı, Inheritance özelliğini kullanarak SimpleStockManager'a özellikleri aktarır.

public class Main {

    interface LambdaInterface{
        void printIt();
    }
    public static void main(String[] args) {

        LambdaInterface PrintIt = () ->  System.out.println("Geçersiz seçenek. Tekrar deneyin.");
        Scanner scanner = new Scanner(System.in);
        StockManager<Product> stockManager = new SimpleStockManager<>();

        while (true) {
            System.out.println("1. Ürün Ekle");
            System.out.println("2. Ürünleri Listele");
            System.out.println("3. Stok Güncelle");
            System.out.println("4. Ürün Sil");
            System.out.println("5. Ürün Ara");
            System.out.println("6. Stok Durumu Kontrol Et");
            System.out.println("7. Stok Ekle");
            System.out.println("8. Stok Çıkar");
            System.out.println("9. Çıkış");
            System.out.print("Seçenek girin: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Ürün adı: ");
                    String productName = scanner.next();
                    System.out.print("Stok miktarı: ");
                    int stockQuantity = scanner.nextInt();
                    Product newProduct = new Product(productName, stockQuantity);
                    stockManager.addProduct(newProduct);
                    break;
                case 2:
                    stockManager.listProducts();
                    break;
                case 3:
                    stockManager.listProducts();
                    System.out.print("Stok güncellenecek ürün adı: ");
                    String updateProductName = scanner.next();
                    System.out.print("Stok miktarı: ");
                    int updateQuantity = scanner.nextInt();

                    for (Product product : ((SimpleStockManager<Product>) stockManager).findProductByName(updateProductName)) {
                        stockManager.updateStock(product, updateQuantity);
                    }
                    break;
                case 4:
                    stockManager.listProducts();
                    System.out.print("Silinecek ürün adı: ");
                    String deleteProductName = scanner.next();
                    List<Product> foundProducts = ((SimpleStockManager<Product>) stockManager).findProductByName(deleteProductName);
                    if (!foundProducts.isEmpty()) {
                        for (Product foundProduct : foundProducts) {
                            stockManager.removeProduct(foundProduct);
                        }
                    } else {
                        System.out.println("Ürün bulunamadı.");
                    }
                    break;
                case 5:
                    System.out.print("Aranacak ürün adı: ");
                    String searchProductName = scanner.next();
                    List<Product> searchResult = ((SimpleStockManager<Product>) stockManager).findProductByName(searchProductName);
                    if (!searchResult.isEmpty()) {
                        System.out.println("Aranan ürünler:");
                        for (Product resultProduct : searchResult) {
                            System.out.println(resultProduct);
                        }
                    } else {
                        System.out.println("Ürün bulunamadı.");
                    }
                    break;
                case 6:
                    stockManager.listProducts();
                    System.out.print("Stok durumu kontrol edilecek ürün adı: ");
                    String stockCheckProductName = scanner.next();
                    List<Product> stockCheckResult = ((SimpleStockManager<Product>) stockManager).findProductByName(stockCheckProductName);
                    if (!stockCheckResult.isEmpty()) {
                        System.out.print("Kontrol edilecek miktar: ");
                        int stockCheckQuantity = scanner.nextInt();

                        StockManager<Product> finalStockManager = stockManager;
                        for (Product stockCheckProduct : stockCheckResult) {
                            // Lambda fonksiyonu kullanımı
                            boolean stockAvailability = finalStockManager.checkStockAvailability(stockCheckProduct, stockCheckQuantity);
                            if (stockAvailability) {
                                System.out.println("Stokta yeterli miktar bulunmaktadır.");
                            } else {
                                System.out.println("Stokta yeterli miktar bulunmamaktadır.");
                            }
                        }
                    } else {
                        System.out.println("Ürün bulunamadı.");
                    }
                    break;
                case 7:
                    stockManager.listProducts();
                    System.out.print("Stok eklemek istediğiniz ürün adı: ");
                    String increaseStockProductName = scanner.next();
                    List<Product> increaseStockResult = ((SimpleStockManager<Product>) stockManager).findProductByName(increaseStockProductName);
                    if (!increaseStockResult.isEmpty()) {
                        System.out.print("Eklemek istediğiniz stok miktarı: ");
                        int increaseStockQuantity = scanner.nextInt();
                        for (Product increaseStockProduct : increaseStockResult) {
                            stockManager.increaseStock(increaseStockProduct, increaseStockQuantity);
                        }
                    } else {
                        System.out.println("Ürün bulunamadı.");
                    }
                    break;
                case 8:
                    stockManager.listProducts();
                    System.out.print("Stok çıkarmak istediğiniz ürün adı: ");
                    String decreaseStockProductName = scanner.next();
                    List<Product> decreaseStockResult = ((SimpleStockManager<Product>) stockManager).findProductByName(decreaseStockProductName);
                    if (!decreaseStockResult.isEmpty()) {
                        System.out.print("Çıkarmak istediğiniz stok miktarı: ");
                        int decreaseStockQuantity = scanner.nextInt();
                        for (Product decreaseStockProduct : decreaseStockResult) {
                            stockManager.decreaseStock(decreaseStockProduct, decreaseStockQuantity);
                        }
                    } else {
                        System.out.println("Ürün bulunamadı.");
                    }
                    break;
                case 9:
                    System.out.println("Çıkış yapılıyor...");
                    System.exit(0);
                    break;
                default:
                    PrintIt.printIt();
            }
        }
    }
}
